from datetime import date

import pytest

from app.resume_intelligence import (
    extract_resume_intelligence,
    split_sections,
)


SAMPLE = """Avery Stone
avery@example.com
+1 415 555 0134

SUMMARY
Software engineer with 4 years of professional experience.

SKILLS
Python, FastAPI, PostgreSQL, Docker, NLP

EXPERIENCE
Software Engineer | Acme
Jan 2022 - Dec 2024
Built REST APIs using Python and FastAPI.

INTERNSHIPS
ML Intern | Lab
Jun 2021 - Aug 2021
Worked on NLP prototypes.

EDUCATION
Bachelor of Computer Science

PROJECTS
Resume matcher using Python and NLP.
"""


def test_extracts_contact_and_candidate_name():
    result = extract_resume_intelligence(SAMPLE, date(2025, 1, 1))
    assert result["candidate"]["name"] == "Avery Stone"
    assert result["candidate"]["email"] == "avery@example.com"
    assert result["candidate"]["phone"] is not None


def test_skills_have_evidence_and_section():
    result = extract_resume_intelligence(SAMPLE, date(2025, 1, 1))
    skills = {item["name"]: item for item in result["skills"]}
    assert "python" in skills
    assert "skills" in skills["python"]["sections"]
    assert skills["python"]["evidence"]


def test_professional_and_internship_experience_are_separate():
    result = extract_resume_intelligence(SAMPLE, date(2025, 1, 1))
    exp = result["experience"]
    assert exp["professional_experience_years"] == 3.0
    assert exp["internship_experience_years"] == pytest.approx(0.25)
    assert exp["stated_experience_years"] == 4.0


def test_projects_are_not_counted_as_employment():
    result = extract_resume_intelligence(SAMPLE, date(2025, 1, 1))
    exp = result["experience"]
    assert exp["professional_experience_years"] == 3.0
    assert exp["project_evidence"]


def test_empty_resume_is_rejected():
    with pytest.raises(ValueError, match="empty"):
        extract_resume_intelligence("   ")


def test_sections_are_detected():
    sections = split_sections(SAMPLE)
    assert "skills" in sections
    assert "experience" in sections
    assert "internships" in sections
    assert "education" in sections
